LOOP

Loop is a local two player game. Who first reaches the
middle of the maze wins. 
You control Player 1 with a+d+w and Player 2 with the
arrow keys.

====================

Unzip the file
Open the .exe file
The game should start